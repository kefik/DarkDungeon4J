
  /*   2010 (C) Jussi Rintanen  */

satinstance DIMACSinput();
