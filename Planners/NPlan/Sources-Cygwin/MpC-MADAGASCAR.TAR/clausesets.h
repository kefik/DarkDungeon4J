
/*   2010 (C) Jussi Rintanen   */

/* Literal and types:

 */

#define UNASS -1

int propagate(satinstance,int);

void init_clausesets();
